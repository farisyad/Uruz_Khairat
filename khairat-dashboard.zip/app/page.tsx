"use client"

import Component from "../dashboard"

export default function Page() {
  return <Component />
}
