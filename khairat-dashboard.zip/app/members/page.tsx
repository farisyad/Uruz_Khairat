"use client"

import MemberList from "../../member-list"

export default function MembersPage() {
  return <MemberList />
}
